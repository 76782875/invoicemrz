package trees;

class Hertz {  
	public static double classify(Object[] i)    throws Exception {
		double p = Double.NaN;
		p = Hertz.N297746790(i);
		return p;
	}
	static double N297746790(Object []i) {
		double p = Double.NaN;
		if (i[17] == null) {
			p = 0;    
		} else if (((Double) i[17]).doubleValue() <= 0.9319327731092437) {
			p = 0;
		} else if (((Double) i[17]).doubleValue() > 0.9319327731092437) {
			p = Hertz.N3ffc5af11(i);    
		}     
		return p;  
	}  
	static double N3ffc5af11(Object []i) {
		double p = Double.NaN;
		if (i[70] == null) { 
			p = 0;    
		} else if (((Double) i[70]).doubleValue() <= 4.453967760325716) {
			p = 0;    
		} else if (((Double) i[70]).doubleValue() > 4.453967760325716) {
			p = 1;    
		}
		return p;  
	}
}
