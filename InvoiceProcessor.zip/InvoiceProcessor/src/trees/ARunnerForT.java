package trees;
import java.lang.reflect.Method;

public class ARunnerForT {
	  /**
	   * Call a static method of a class.
	   */
	  public static Object callStaticMethod (String className, 
	                                         String methodName,
	                                         Class[] signature,
	                                         Object[] args) 
	      {
		  try{
		      Class cls = Class.forName ("trees." + className);
		      Method method = cls.getMethod (methodName, signature);
		      method.setAccessible(true);
		      return method.invoke (cls, args);
	      }catch (Exception ex){
	    	  return null;
	      }
	  }
}


