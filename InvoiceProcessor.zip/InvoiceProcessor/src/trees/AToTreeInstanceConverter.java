package trees;

import base.ContentCategory;
import base.PresentationCategory;

public class AToTreeInstanceConverter {
	/*
	Attribute[] attributes = {classAtt, 
			positionElementX1, positionElementY1, positionElementX2, positionElementY2, 
			positionLeftX1, positionLeftY1, positionLeftX2, positionLeftY2, 
			positionLeftValue,
			positionTopX1, positionTopY1, positionTopX2, positionTopY2, 
			positionTopValue,
			positionRightX1, positionRightY1, positionRightX2, positionRightY2, 
			positionRightValue,
			positionBottomX1, positionBottomY1, positionBottomX2, positionBottomY2, 
			positionBottomValue,
			
			positionTopLeftX1, positionTopLeftY1, positionTopLeftX2, positionTopLeftY2, 
			positionTopLeftValue,
			positionTopRightX1, positionTopRightY1, positionTopRightX2, positionTopRightY2, 
			positionTopRightValue,
			positionBottomRightX1, positionBottomRightY1, positionBottomRightX2, positionBottomRightY2, 
			positionBottomRightValue,
			positionBottomLeftX1, positionBottomLeftY1, positionBottomLeftX2, positionBottomLeftY2, 
			positionBottomLeftValue,
			
			contentElementValue, contentLeftValue, contentTopValue, contentRightValue, contentBottomValue,
			contentTopLeftValue, contentTopRightValue, contentBottomRightValue, contentBottomLeftValue,
			presentationElementValue, presentationLeftValue, presentationTopValue, presentationRightValue, presentationBottomValue,
			presentationTopLeftValue, presentationTopRightValue, presentationBottomRightValue, presentationBottomLeftValue,
			distanceFromLeftValue, distanceFromTopValue, distanceFromRightValue, distanceFromBottomValue,
			distanceFromTopLeftValue, distanceFromTopRightValue, distanceFromBottomRightValue, distanceFromBottomLeftValue		
	};
	*/
	
	public static Object[] convert(int totalN, int N, Object[] columns){
		
		   String found = String.valueOf(columns[0]);
		   String tp = String.valueOf(columns[1]);
		   String instance = String.valueOf(columns[2]);
		   
		   Integer numPages = (Integer)columns[3];
		   Double pageWidth = (Double)columns[4];
		   Double pageHeight = (Double)columns[5];
		   
		   int S = 6;
		   
		   Object[] instanceItems = new Object[totalN - 1];
		   int index = 0;
 		   int mainValueIndex = 0; 
		   String mainValue = "";
		   
		   int[] valueIndexes = new int[N - 1];
		   for (int o = 0; o < 2; o++){
			    instanceItems[index] = (Double)(columns[S + index])/pageWidth;
				index++;
				instanceItems[index] = (Double)(columns[S + index])/pageHeight;
				index++;
				instanceItems[index] = (Double)(columns[S + index])/pageWidth;
				index++;
				instanceItems[index] = (Double)(columns[S + index])/pageHeight;
				index++;
		   }
		   valueIndexes[0] = index;
		   int shift = 1;
		   for (int o = 0; o < N - 2; o++){
			    instanceItems[index + shift] = (Double)(columns[S + index])/pageWidth;
				index++;
				instanceItems[index + shift] = (Double)(columns[S + index])/pageHeight;
				index++;
				instanceItems[index + shift] = (Double)(columns[S + index])/pageWidth;
				index++;
				instanceItems[index + shift] = (Double)(columns[S + index])/pageHeight;
				index++;
				
				valueIndexes[shift] = index + shift;
				shift += 1;
		   }
		   for (int o = 0; o < N; o++){
			    if (o == 0){
			    	mainValueIndex = S + index;
			    	mainValue = String.valueOf(columns[mainValueIndex]);
			    }else{
			    	instanceItems[valueIndexes[o - 1]] = columns[S + index];
			    }
			    index++;
		   }
		   
		   /*
		   for (int o = 0; o < N; o++){
			    instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageWidth));
				index++;
				instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageHeight));
				index++;
				instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageWidth));
				index++;
				instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageHeight));
				index++;
		   }
		   for (int o = 0; o < N; o++){
			    if (o == 0){
			    	mainValueIndex = S + index;
			    	mainValue = columns[mainValueIndex];
			    }else{
			    	instanceItems[index - 1] = columns[S + index];
			    }
			    index++;
		   }
		   */
		   for (int o = 0; o < N; o++){
			    instanceItems[index - 1] = ((ContentCategory)columns[S + index]).toString();
			    index++;
		   }
		   for (int o = 0; o < N; o++){
			    instanceItems[index - 1] = ((PresentationCategory)columns[S + index]).toString();
				index++;
		   } 
		   double divider = Math.sqrt(Double.valueOf(pageHeight) + Double.valueOf(pageWidth));
		   for (int o = 0; o < N-1; o++){
			    instanceItems[index - 1] = (Double)(columns[S + index])/divider;
			    index++;
		   } 
		   
		   Object[] instanceItems_start1 = new Object[totalN];
		   instanceItems_start1[0] = 0;
		   
		   for (int i = 1; i < totalN; i++){
			   instanceItems_start1[i] = instanceItems[i - 1];
		   }
		   
		   return instanceItems_start1;
	}
}
