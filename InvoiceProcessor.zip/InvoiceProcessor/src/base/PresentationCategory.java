package base;

public enum PresentationCategory {
	NONE, ALLUPPERWORD, ALLLOWERWORD, WORD
}
