package base;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToNominal;

public class ModelBuilder {
	
	private static int N = 9;
	private static int totalN = 4*N + 3*N + (N -1);
	
	public static void main(String[] args) throws Exception{
		
		List<String> insts = mapAll("instances.txt", "outcomes.txt");
		reduce(insts, "Hertz");
	}
	
	public static List<String> mapAll(String instancesFile, String outcomesFile) throws Exception{
		List<String> instances = new LinkedList<String>(); 
		
		// read outcomes
		Map<String, String> outcomes = new HashMap<String, String>();
		try(BufferedReader br = new BufferedReader(new FileReader(outcomesFile))) {
		    String line = br.readLine();
		    while (line != null) {
		    	String[] parts = line.split("\t");
		    	if (parts.length == 2){
		    		outcomes.put(parts[0], parts[1]);
		    		line = br.readLine();
		        }
		    }
		}
		
		try(BufferedReader br = new BufferedReader(new FileReader("instances.txt"))) {
		    String line = br.readLine();

		    while (line != null) {
		    	int k = line.indexOf("\t");
		    	String fileName = line.substring(0,k).trim();
		    	String inst = line.substring(k + 1).trim();
		    	String outcome = outcomes.get(fileName);
		    	if (outcome == null || outcome.isEmpty()){
		    		continue;
		    	}
		        String instance = map(inst, outcome, true);
		        instances.add(instance);
		        line = br.readLine();
		    }
		}
		
		return instances;
	} 
	
	public static String map(String currentInstance, String value, boolean isDouble) {
		String[] columns = currentInstance.toString().split("\t");
		
		String found = columns[5 - 5];
		String tp = columns[6 - 5];
		String instance = columns[7 - 5];
		
		String numPages = columns[8 - 5];
		String pageWidth = columns[9 - 5];
		String pageHeight = columns[10  - 5];
	
		int S = 11 - 5;

		if (!(tp.equals("text") || tp.equals("scan") || tp.equals("unclear"))){
		   return null;
		}
		
		if (!instance.equals("true")){
		   return null;
		} 
		
		String[] instanceItems = new String[totalN - 1];
		int index = 0;
		int mainValueIndex = 0; 
		String mainValue = "";
		for (int o = 0; o < N; o++){
		    instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageWidth));
			index++;
			instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageHeight));
			index++;
			instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageWidth));
			index++;
			instanceItems[index] = String.valueOf(Double.valueOf(columns[S + index])/Double.valueOf(pageHeight));
			index++;
		}
		for (int o = 0; o < N; o++){
		    if (o == 0){
		    	mainValueIndex = S + index;
		    	mainValue = columns[mainValueIndex];
		    }else{
		    	instanceItems[index - 1] = columns[S + index];
		    }
		    index++;
		}
		for (int o = 0; o < N; o++){
		    instanceItems[index - 1] = columns[S + index];
		    index++;
		}
		for (int o = 0; o < N; o++){
		    instanceItems[index - 1] = columns[S + index];
			index++;
		} 
		double divider = Math.sqrt(Double.valueOf(pageHeight) + Double.valueOf(pageWidth));
		for (int o = 0; o < N-1; o++){
		    instanceItems[index - 1] = String.valueOf((Double.valueOf(columns[S + index])/divider));
		    index++;
		} 
		
		String classValue = "0";
		
		if (!mainValue.trim().isEmpty()){
		
			if (isDouble == false){	
			   if (mainValue.trim().endsWith(value.trim())){
				   classValue = "1";
			   }
			}else{
			   if (isDoubleValue(mainValue.trim())){
				   if (Double.valueOf(getItemValue(mainValue.trim())).doubleValue() == Double.valueOf(value).doubleValue()){
					   classValue = "1";
				   }
			   }
			}
		}
		
		String result = "";
		for (String item : instanceItems){
		   result = result + "\t";
		   result = result + item;
		}
		
		return classValue + result;
}
	
public static void reduce(List<String> inputs, String className) throws IOException, InterruptedException {

		Attribute classAtt = new Attribute("Class", new ArrayList<String>(Arrays.asList(new String[] {"0", "1"})));
		Attribute positionElementX1 = new Attribute("positionElementX1");
		Attribute positionElementY1 = new Attribute("positionElementY1");
		Attribute positionElementX2 = new Attribute("positionElementX2");
		Attribute positionElementY2 = new Attribute("positionElementY2");
		//Attribute positionElementValue = new Attribute("positionElementY2", (ArrayList<String>)null);
		Attribute positionLeftX1 = new Attribute("positionLeftX1");
		Attribute positionLeftY1 = new Attribute("positionLeftY1");
		Attribute positionLeftX2 = new Attribute("positionLeftX2");
		Attribute positionLeftY2 = new Attribute("positionLeftY2");
		Attribute positionLeftValue = new Attribute("positionLeftValue", (ArrayList<String>)null);
		Attribute positionTopX1 = new Attribute("positionTopX1");
		Attribute positionTopY1 = new Attribute("positionTopY1");
		Attribute positionTopX2 = new Attribute("positionTopX2");
		Attribute positionTopY2 = new Attribute("positionTopY2");
		Attribute positionTopValue = new Attribute("positionTopValue", (ArrayList<String>)null);
		Attribute positionRightX1 = new Attribute("positionRightX1");
		Attribute positionRightY1 = new Attribute("positionRightY1");
		Attribute positionRightX2 = new Attribute("positionRightX2");
		Attribute positionRightY2 = new Attribute("positionRightY2");
		Attribute positionRightValue = new Attribute("positionRightValue", (ArrayList<String>)null);
		Attribute positionBottomX1 = new Attribute("positionBottomX1");
		Attribute positionBottomY1 = new Attribute("positionBottomY1");
		Attribute positionBottomX2 = new Attribute("positionBottomX2");
		Attribute positionBottomY2 = new Attribute("positionBottomY2");
		Attribute positionBottomValue = new Attribute("positionBottomValue", (ArrayList<String>)null);
		
		
		Attribute positionTopLeftX1 = new Attribute("positionTopLeftX1");
		Attribute positionTopLeftY1 = new Attribute("positionTopLeftY1");
		Attribute positionTopLeftX2 = new Attribute("positionTopLeftX2");
		Attribute positionTopLeftY2 = new Attribute("positionTopLeftY2");
		Attribute positionTopLeftValue = new Attribute("positionTopLeftValue", (ArrayList<String>)null);
		Attribute positionTopRightX1 = new Attribute("positionTopRightX1");
		Attribute positionTopRightY1 = new Attribute("positionTopRightY1");
		Attribute positionTopRightX2 = new Attribute("positionTopRightX2");
		Attribute positionTopRightY2 = new Attribute("positionTopRightY2");
		Attribute positionTopRightValue = new Attribute("positionTopRightValue", (ArrayList<String>)null);
		Attribute positionBottomRightX1 = new Attribute("positionBottomRightX1");
		Attribute positionBottomRightY1 = new Attribute("positionBottomRightY1");
		Attribute positionBottomRightX2 = new Attribute("positionBottomRightX2");
		Attribute positionBottomRightY2 = new Attribute("positionBottomRightY2");
		Attribute positionBottomRightValue = new Attribute("positionBottomRightValue", (ArrayList<String>)null);
		Attribute positionBottomLeftX1 = new Attribute("positionBottomLeftX1");
		Attribute positionBottomLeftY1 = new Attribute("positionBottomLeftY1");
		Attribute positionBottomLeftX2 = new Attribute("positionBottomLeftX2");
		Attribute positionBottomLeftY2 = new Attribute("positionBottomLeftY2");
		Attribute positionBottomLeftValue = new Attribute("positionBottomLeftValue", (ArrayList<String>)null);
		
		
		Attribute contentElementValue = new Attribute("contentElementValue", (ArrayList<String>)null);
		Attribute contentLeftValue = new Attribute("contentLeftValue", (ArrayList<String>)null);
		Attribute contentTopValue = new Attribute("contentTopValue", (ArrayList<String>)null);
		Attribute contentRightValue = new Attribute("contentRightValue", (ArrayList<String>)null);
		Attribute contentBottomValue = new Attribute("contentBottomValue", (ArrayList<String>)null);
		
		Attribute presentationElementValue = new Attribute("presentationElementValue", (ArrayList<String>)null);
		Attribute presentationLeftValue = new Attribute("presentationLeftValue", (ArrayList<String>)null);
		Attribute presentationTopValue = new Attribute("presentationTopValue", (ArrayList<String>)null);
		Attribute presentationRightValue = new Attribute("presentationRightValue", (ArrayList<String>)null);
		Attribute presentationBottomValue = new Attribute("presentationBottomValue", (ArrayList<String>)null);
		
		Attribute distanceFromLeftValue = new Attribute("distanceFromLeft");
		Attribute distanceFromTopValue = new Attribute("distanceFromTop");
		Attribute distanceFromRightValue = new Attribute("distanceFromRight");
		Attribute distanceFromBottomValue = new Attribute("distanceFromBottom");
		
		
		Attribute contentTopLeftValue = new Attribute("contentTopLeftValue", (ArrayList<String>)null);
		Attribute contentTopRightValue = new Attribute("contentTopRightValue", (ArrayList<String>)null);
		Attribute contentBottomRightValue = new Attribute("contentBottomRightValue", (ArrayList<String>)null);
		Attribute contentBottomLeftValue = new Attribute("contentBottomLeftValue", (ArrayList<String>)null);
		
		Attribute presentationTopLeftValue = new Attribute("presentationTopLeftValue", (ArrayList<String>)null);
		Attribute presentationTopRightValue = new Attribute("presentationTopRightValue", (ArrayList<String>)null);
		Attribute presentationBottomRightValue = new Attribute("presentationBottomRightValue", (ArrayList<String>)null);
		Attribute presentationBottomLeftValue = new Attribute("presentationBottomLeftValue", (ArrayList<String>)null);
		
		Attribute distanceFromTopLeftValue = new Attribute("distanceFromTopLeft");
		Attribute distanceFromTopRightValue = new Attribute("distanceFromTopRight");
		Attribute distanceFromBottomRightValue = new Attribute("distanceFromBottomRight");
		Attribute distanceFromBottomLeftValue = new Attribute("distanceFromBottomLeft");


		Attribute[] attributes = {classAtt, 
				positionElementX1, positionElementY1, positionElementX2, positionElementY2, 
				positionLeftX1, positionLeftY1, positionLeftX2, positionLeftY2, 
				positionLeftValue,
				positionTopX1, positionTopY1, positionTopX2, positionTopY2, 
				positionTopValue,
				positionRightX1, positionRightY1, positionRightX2, positionRightY2, 
				positionRightValue,
				positionBottomX1, positionBottomY1, positionBottomX2, positionBottomY2, 
				positionBottomValue,
				
				positionTopLeftX1, positionTopLeftY1, positionTopLeftX2, positionTopLeftY2, 
				positionTopLeftValue,
				positionTopRightX1, positionTopRightY1, positionTopRightX2, positionTopRightY2, 
				positionTopRightValue,
				positionBottomRightX1, positionBottomRightY1, positionBottomRightX2, positionBottomRightY2, 
				positionBottomRightValue,
				positionBottomLeftX1, positionBottomLeftY1, positionBottomLeftX2, positionBottomLeftY2, 
				positionBottomLeftValue,
				
				contentElementValue, contentLeftValue, contentTopValue, contentRightValue, contentBottomValue,
				contentTopLeftValue, contentTopRightValue, contentBottomRightValue, contentBottomLeftValue,
				presentationElementValue, presentationLeftValue, presentationTopValue, presentationRightValue, presentationBottomValue,
				presentationTopLeftValue, presentationTopRightValue, presentationBottomRightValue, presentationBottomLeftValue,
				distanceFromLeftValue, distanceFromTopValue, distanceFromRightValue, distanceFromBottomValue,
				distanceFromTopLeftValue, distanceFromTopRightValue, distanceFromBottomRightValue, distanceFromBottomLeftValue		
		};

		Instances instances = null; 
		instances = new Instances("invoice data", new ArrayList<Attribute>(Arrays.asList(attributes)), 0);
		instances.setClassIndex(0);

		for (String val : inputs) {
			String[] items = val.toString().split("\t");
			
			if (items.length != totalN){
				continue;
			}
			
			DenseInstance inst = new DenseInstance(attributes.length);
			inst.setDataset(instances);
			int valIndex = instances.attribute("Class").indexOfValue("0");
			//inst.setClassValue(items[0]);
			if (items[0].equals("1")){
				valIndex = instances.attribute("Class").indexOfValue("1");
			}
			inst.setValue(classAtt, valIndex);
			
			inst.setValue(positionElementX1, getItemValue(items[1]));
			inst.setValue(positionElementY1, getItemValue(items[2]));
			inst.setValue(positionElementX2, getItemValue(items[3]));
			inst.setValue(positionElementY2, getItemValue(items[4]));
			
			inst.setValue(positionLeftX1, getItemValue(items[5]));
			inst.setValue(positionLeftY1, getItemValue(items[6]));
			inst.setValue(positionLeftX2, getItemValue(items[7]));
			inst.setValue(positionLeftY2, getItemValue(items[8]));
			
			inst.setValue(positionTopX1, getItemValue(items[9]));
			inst.setValue(positionTopY1, getItemValue(items[10]));
			inst.setValue(positionTopX2, getItemValue(items[11]));
			inst.setValue(positionTopY2, getItemValue(items[12]));
			
			inst.setValue(positionRightX1, getItemValue(items[13]));
			inst.setValue(positionRightY1, getItemValue(items[14]));
			inst.setValue(positionRightX2, getItemValue(items[15]));
			inst.setValue(positionRightY2, getItemValue(items[16]));
			
			inst.setValue(positionBottomX1, getItemValue(items[17]));
			inst.setValue(positionBottomY1, getItemValue(items[18]));
			inst.setValue(positionBottomX2, getItemValue(items[19]));
			inst.setValue(positionBottomY2, getItemValue(items[20]));
			
			inst.setValue(positionTopLeftX1, getItemValue(items[21]));
			inst.setValue(positionTopLeftY1, getItemValue(items[22]));
			inst.setValue(positionTopLeftX2, getItemValue(items[23]));
			inst.setValue(positionTopLeftY2, getItemValue(items[24]));
			
			inst.setValue(positionTopRightX1, getItemValue(items[25]));
			inst.setValue(positionTopRightY1, getItemValue(items[26]));
			inst.setValue(positionTopRightX2, getItemValue(items[27]));
			inst.setValue(positionTopRightY2, getItemValue(items[28]));
			
			inst.setValue(positionBottomRightX1, getItemValue(items[29]));
			inst.setValue(positionBottomRightY1, getItemValue(items[30]));
			inst.setValue(positionBottomRightX2, getItemValue(items[31]));
			inst.setValue(positionBottomRightY2, getItemValue(items[32]));
			
			inst.setValue(positionBottomLeftX1, getItemValue(items[33]));
			inst.setValue(positionBottomLeftY1, getItemValue(items[34]));
			inst.setValue(positionBottomLeftX2, getItemValue(items[35]));
			inst.setValue(positionBottomLeftY2, getItemValue(items[36]));
			
			inst.setValue(positionLeftValue, items[37]);
			inst.setValue(positionTopValue, items[38]);
			inst.setValue(positionRightValue, items[39]);
			inst.setValue(positionBottomValue, items[40]);
			
			inst.setValue(positionTopLeftValue, items[41]);
			inst.setValue(positionTopRightValue, items[42]);
			inst.setValue(positionBottomRightValue, items[43]);
			inst.setValue(positionBottomLeftValue, items[44]);
			
			inst.setValue(contentElementValue, items[45]);
			inst.setValue(contentLeftValue, items[46]);
			inst.setValue(contentTopValue, items[47]);
			inst.setValue(contentRightValue, items[48]);
			inst.setValue(contentBottomValue, items[49]);
			
			inst.setValue(contentTopLeftValue, items[50]);
			inst.setValue(contentTopRightValue, items[51]);
			inst.setValue(contentBottomRightValue, items[52]);
			inst.setValue(contentBottomLeftValue, items[53]);
			
			inst.setValue(presentationElementValue, items[54]);
			inst.setValue(presentationLeftValue, items[55]);
			inst.setValue(presentationTopValue, items[56]);
			inst.setValue(presentationRightValue, items[57]);
			inst.setValue(presentationBottomValue, items[58]);
			
			inst.setValue(presentationTopLeftValue, items[59]);
			inst.setValue(presentationTopRightValue, items[60]);
			inst.setValue(presentationBottomRightValue, items[61]);
			inst.setValue(presentationBottomLeftValue, items[62]);
			
			inst.setValue(distanceFromLeftValue, getItemValue(items[63]));
			inst.setValue(distanceFromTopValue, getItemValue(items[64]));
			inst.setValue(distanceFromRightValue, getItemValue(items[65]));
			inst.setValue(distanceFromBottomValue, getItemValue(items[66]));
			
			inst.setValue(distanceFromTopLeftValue, getItemValue(items[67]));
			inst.setValue(distanceFromTopRightValue, getItemValue(items[68]));
			inst.setValue(distanceFromBottomRightValue, getItemValue(items[69]));
			inst.setValue(distanceFromBottomLeftValue, getItemValue(items[70]));
			
			instances.add(inst);
	}

	try{
		StringToNominal stringToNominal = new StringToNominal();
		stringToNominal.setAttributeRange(
				(instances.attribute("positionLeftValue").index() + 1) + 
		   "," + (instances.attribute("positionTopValue").index() + 1) +
		   "," + (instances.attribute("positionRightValue").index() + 1) +
		   "," + (instances.attribute("positionBottomValue").index() + 1) +
		   
		   "," + (instances.attribute("positionTopLeftValue").index() + 1) + 
		   "," + (instances.attribute("positionTopRightValue").index() + 1) +
		   "," + (instances.attribute("positionBottomRightValue").index() + 1) +
		   "," + (instances.attribute("positionBottomLeftValue").index() + 1) +
		   
		   "," + (instances.attribute("contentElementValue").index() + 1) +
		   "," + (instances.attribute("contentLeftValue").index() + 1) +
		   "," + (instances.attribute("contentTopValue").index() + 1) +
		   "," + (instances.attribute("contentRightValue").index() + 1) +
		   "," + (instances.attribute("contentBottomValue").index() + 1) +
		   
		   "," + (instances.attribute("contentTopLeftValue").index() + 1) +
		   "," + (instances.attribute("contentTopRightValue").index() + 1) +
		   "," + (instances.attribute("contentBottomRightValue").index() + 1) +
		   "," + (instances.attribute("contentBottomLeftValue").index() + 1) +
		   
		   "," + (instances.attribute("presentationElementValue").index() + 1) +
		   "," + (instances.attribute("presentationLeftValue").index() + 1) +
		   "," + (instances.attribute("presentationTopValue").index() + 1) +
		   "," + (instances.attribute("presentationRightValue").index() + 1) +
		   "," + (instances.attribute("presentationBottomValue").index() + 1) +
		   
		   "," + (instances.attribute("presentationTopLeftValue").index() + 1) +
		   "," + (instances.attribute("presentationTopRightValue").index() + 1) +
		   "," + (instances.attribute("presentationBottomRightValue").index() + 1) +
		   "," + (instances.attribute("presentationBottomLeftValue").index() + 1)
		   );
		stringToNominal.setInputFormat(instances);

		Instances newData = Filter.useFilter(instances, stringToNominal);   
		
		J48 j48 = new J48();
		j48.setSeed(1);
		j48.setBinarySplits(true);
		j48.setMinNumObj(5);
		//j48.setSaveInstanceData(true);
		
		j48.buildClassifier(newData);
		
		String source = j48.toSource(className).replaceAll("\n", "").replaceAll("\t", " ");
		//String prefix = j48.prefix().replaceAll("\n", "").replaceAll("\t", " ");
		Evaluation eval = new Evaluation(newData);
		eval.evaluateModel(j48, newData);
		double[][] confusionMatrix = eval.confusionMatrix();
		
		System.out.println(j48.measureNumLeaves() + "\t" + j48.measureTreeSize() + "\t" + confusionMatrix[0][0] + "\t" + confusionMatrix[0][1] + "\t" + confusionMatrix[1][0] + "\t" + confusionMatrix[1][1] + "\t" + source);
	} catch (Exception ex){
		ex.printStackTrace();
		System.out.println(0 + "\t" + 0 + "\t" + 0.0 + "\t" + 0.0 + "\t" + 0.0 + "\t" + 0.0 + "\t" + "");
	}
}
	private static double getItemValue(String item){
		String str = item.replaceAll("[$]", "");
		str = str.replaceAll(",", "");
		
		double k = 0.0;
		try{
			k = Double.valueOf(str);
		}catch (Exception e){
			if (!item.contains("$")){
				return 0.0;
			}
			
			String[] suffixes = item.split("[$]");
			
			if (suffixes.length <= 1){
				return 0.0;
			}
			
			String suffix = suffixes[1].replaceAll(",", "");
			
			try{
				k = Double.valueOf(suffix);
			}catch (Exception ex){
				return 0.0;
			}
		}
		return k;
	}

	private static boolean isDoubleValue(String item){
		String str = item.replaceAll("[$]", "");
		str = str.replaceAll(",", "");
		
		try{
			double k = Double.valueOf(str);
		}catch (Exception e){
			if (!item.contains("$")){
				return false;
			}
			
			String[] suffixes = item.split("[$]");
			
			if (suffixes.length <= 1){
				return false;
			}
			
			String suffix = suffixes[1].replaceAll(",", "");
			
			try{
				double k = Double.valueOf(suffix);
			}catch (Exception ex){
				return false;
			}
		}
		return true;
	}
}
