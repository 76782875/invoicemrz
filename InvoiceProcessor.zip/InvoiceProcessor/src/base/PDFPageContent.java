package base;

import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class PDFPageContent implements Iterator<WCClaimPageRectangle> {
	private List<WCClaimPageRectangle> wordList = new LinkedList<WCClaimPageRectangle>();
	int pos = 0, n;
	
	public PDFPageContent (List<WCClaimPageRectangle> input, int n){
		this.wordList.addAll(input);
		this.n = n;
	}
	
	public List<WCClaimPageRectangle> getAll(){
		return wordList;
	}
	
	public List<WCClaimPageRectangle> getByWord(String keyword){
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		for (WCClaimPageRectangle word : wordList){
			if (word.getText().equals(keyword)){
				matches.add(word);
			}
		}
		return matches;
	}
	
	public List<WCClaimPageRectangle> getAllBeforeX(WCClaimPageRectangle x){
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		for (WCClaimPageRectangle word : wordList){
			if (word.equals(x)){
				continue;
			}
			if (word.getRectangle().getWidth()  <  x.getRectangle().getX()){
				matches.add(word);
			}
		}
		return matches;
	}
	
	public List<WCClaimPageRectangle> getAllAfterX(WCClaimPageRectangle x){
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		for (WCClaimPageRectangle word : wordList){
			if (word.equals(x)){
				continue;
			}
			if (word.getRectangle().getX()  >  x.getRectangle().getWidth()){
				matches.add(word);
			}
		}
		return matches;
	}
	
	public List<WCClaimPageRectangle> getAllBelowY(WCClaimPageRectangle y){
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		for (WCClaimPageRectangle word : wordList){
			if (word.equals(y)){
				continue;
			}
			if (word.getRectangle().getY()  >  y.getRectangle().getHeight()){
				matches.add(word);
			}
		}
		return matches;
	}
	
	public List<WCClaimPageRectangle> getAllAboveY(WCClaimPageRectangle y){
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		for (WCClaimPageRectangle word : wordList){
			if (word.equals(y)){
				continue;
			}
			if (word.getRectangle().getHeight()  <  y.getRectangle().getY()){
				matches.add(word);
			}
		}
		return matches;
	}
	
	public double getIntersection(double a1, double a2, double b1, double b2){
		
		List<Double> dots = new ArrayList<Double>();
		dots.add(a1);
		dots.add(a2);
		dots.add(b1);
		dots.add(b2);
		
		Collections.sort(dots);
		
		if (Math.abs(dots.get(0) - dots.get(3)) > Math.abs(a1 - a2) + Math.abs(b1 - b2))
			return 0;
		
		return Math.abs(dots.get(1) - dots.get(2));
	}
	
	public WCClaimPageRectangle getLeft(WCClaimPageRectangle rectangle){
		List<WCClaimPageRectangle> rects = getAllBeforeX(rectangle);
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();		

		if (rectangle == null){
			return null;
		}
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		for (WCClaimPageRectangle word : rects){
			double intersection = getIntersection(word.getRectangle().getY(), word.getRectangle().getHeight(), rectangle.getRectangle().getY(), rectangle.getRectangle().getHeight());
			if (intersection > 0.0){
				matches.add(word);
			}
		}

		if (matches.isEmpty()){
			return null;
		}
		
		Collections.sort(matches, new XComparator());
		return matches.get(matches.size() - 1);
	}
	
	public WCClaimPageRectangle getRight(WCClaimPageRectangle rectangle){
		List<WCClaimPageRectangle> rects = getAllAfterX(rectangle);
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();		

		if (rectangle == null){
			return null;
		}
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		for (WCClaimPageRectangle word : rects){
			double intersection = getIntersection(word.getRectangle().getY(), word.getRectangle().getHeight(), rectangle.getRectangle().getY(), rectangle.getRectangle().getHeight());
			if (intersection > 0.0){
				matches.add(word);
			}
		}

		if (matches.isEmpty()){
			return null;
		}
		
		Collections.sort(matches, new XComparator());
		return matches.get(0);
	}
	
	public WCClaimPageRectangle getTop(WCClaimPageRectangle rectangle){
		List<WCClaimPageRectangle> rects = getAllAboveY(rectangle);
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		
		if (rectangle == null){
			return null;
		}
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		for (WCClaimPageRectangle word : rects){
			double intersection = getIntersection(word.getRectangle().getX(), word.getRectangle().getWidth(), rectangle.getRectangle().getX(), rectangle.getRectangle().getWidth());
			if (intersection > 0.0){
				matches.add(word);
			}
		}
		
		if (matches.isEmpty()){
			return null;
		}
		
		Collections.sort(matches, new YComparator());
		return matches.get(matches.size() - 1);
	}
	
	public WCClaimPageRectangle getBottom(WCClaimPageRectangle rectangle){
		List<WCClaimPageRectangle> rects = getAllBelowY(rectangle);
		List<WCClaimPageRectangle> matches = new LinkedList<WCClaimPageRectangle>();
		
		if (rectangle == null){
			return null;
		}
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		for (WCClaimPageRectangle word : rects){
			double intersection = getIntersection(word.getRectangle().getX(), word.getRectangle().getWidth(), rectangle.getRectangle().getX(), rectangle.getRectangle().getWidth());
			if (intersection > 0.0){
				matches.add(word);
			}
		}
		
		if (matches.isEmpty()){
			return null;
		}
		
		Collections.sort(matches, new YComparator());
		return matches.get(0);
	}
	
	public WCClaimPageRectangle getLeftBottom(WCClaimPageRectangle rectangle){
		
		if (rectangle == null){
			return null;
		}
		
		List<WCClaimPageRectangle> rects = getAllBelowY(rectangle);
		List<WCClaimPageRectangle> left_rects = getAllBeforeX(rectangle);
		
		rects.retainAll(left_rects);
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		WCClaimPageRectangle closest = null;
		double dist = Double.MAX_VALUE;
		for (WCClaimPageRectangle rect : rects){
			double distanceFromBottomLeft = Math.sqrt(Math.pow(rectangle.getRectangle().getX() - rect.getRectangle().getWidth(), 2) + Math.pow(rectangle.getRectangle().getY() - rect.getRectangle().getY(), 2));
			if (distanceFromBottomLeft < dist){
				closest = rect;
				dist = distanceFromBottomLeft;
			}
		} 
		
		//Collections.sort(rects, new YComparator());
		//return rects.get(0);
		return closest;
	}
	
	public WCClaimPageRectangle getRightBottom(WCClaimPageRectangle rectangle){
		
		if (rectangle == null){
			return null;
		}
		
		List<WCClaimPageRectangle> rects = getAllBelowY(rectangle);
		List<WCClaimPageRectangle> right_rects = getAllAfterX(rectangle);
		
		rects.retainAll(right_rects);
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		WCClaimPageRectangle closest = null;
		double dist = Double.MAX_VALUE;
		for (WCClaimPageRectangle rect : rects){
			double distanceFromBottomRight = Math.sqrt(Math.pow(rectangle.getRectangle().getWidth() - rect.getRectangle().getX(), 2) + Math.pow(rectangle.getRectangle().getHeight() - rect.getRectangle().getY(), 2));
			if (distanceFromBottomRight < dist){
				closest = rect;
				dist = distanceFromBottomRight;
			}
		} 
		
		//Collections.sort(rects, new YComparator());
		//return rects.get(0);
		return closest;
	}
	
	public WCClaimPageRectangle getLeftTop(WCClaimPageRectangle rectangle){
		
		if (rectangle == null){
			return null;
		}
		
		List<WCClaimPageRectangle> rects = getAllAboveY(rectangle);
		List<WCClaimPageRectangle> left_rects = getAllBeforeX(rectangle);
		
		rects.retainAll(left_rects);
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		WCClaimPageRectangle closest = null;
		double dist = Double.MAX_VALUE;
		for (WCClaimPageRectangle rect : rects){
			double distanceFromTopLeft = Math.sqrt(Math.pow(rectangle.getRectangle().getX() - rect.getRectangle().getWidth(), 2) + Math.pow(rectangle.getRectangle().getY() - rect.getRectangle().getHeight(), 2));
			if (distanceFromTopLeft < dist){
				closest = rect;
				dist = distanceFromTopLeft;
			}
		} 
		
		//Collections.sort(rects, new YComparator());
		//return rects.get(rects.size() - 1);
		return closest;
	}
	
	public WCClaimPageRectangle getRightTop(WCClaimPageRectangle rectangle){
		
		if (rectangle == null){
			return null;
		}
		
		List<WCClaimPageRectangle> rects = getAllAboveY(rectangle);
		List<WCClaimPageRectangle> right_rects = getAllAfterX(rectangle);
		
		rects.retainAll(right_rects);
		
		if (rects == null || rects.isEmpty()){
			return null;
		}
		
		WCClaimPageRectangle closest = null;
		double dist = Double.MAX_VALUE;
		for (WCClaimPageRectangle rect : rects){
			double distanceFromTopRight = Math.sqrt(Math.pow(rectangle.getRectangle().getWidth() - rect.getRectangle().getX(), 2) + Math.pow(rectangle.getRectangle().getY() - rect.getRectangle().getHeight(), 2));
			
			if (distanceFromTopRight < dist){
				closest = rect;
				dist = distanceFromTopRight;
			}
		} 
		
		//Collections.sort(rects, new YComparator());
		//return rects.get(rects.size() - 1);
		
		return closest;
	}
	
	protected String roundVal(Double x) {
		DecimalFormat df = new DecimalFormat("#0.00");
		String dx=df.format(x);

	    return dx;
	}

	@Override
	public boolean hasNext() {
		return pos < wordList.size() - n + 1;
	}

	@Override
	public WCClaimPageRectangle next() {
		List<WCClaimPageRectangle> ngramItems = new LinkedList<WCClaimPageRectangle>();
        for (int i = pos; i < pos + n; i++){
        	ngramItems.add(wordList.get(i));
        }
        pos++;
        
        List<Double> Ys = new ArrayList<Double>();
        for (WCClaimPageRectangle ngramItem : ngramItems){
        	if (!Ys.contains(ngramItem.getRectangle().getY())){
        		Ys.add(ngramItem.getRectangle().getY());
        	}
        }
        
        WCClaimPageRectangle rect = null;
        if (Ys.size() == 1){
        	rect = wordList.get(pos);
        	for (int i = pos + 1; i < pos + n; i++){
            	rect = combine(rect, wordList.get(i));
            }
        }
        return rect;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}
	
	private WCClaimPageRectangle combine(WCClaimPageRectangle a1, WCClaimPageRectangle a2){
		WCClaimPageRectangle result = new WCClaimPageRectangle(a1.getRectangle().createUnion(a2.getRectangle()), (a1.getText().trim() + " " + a2.getText().trim()).trim());
		return result;
	}
}
