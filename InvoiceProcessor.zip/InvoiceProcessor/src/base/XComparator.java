package base;

import java.util.Comparator;

public class XComparator implements Comparator<WCClaimPageRectangle>{
	@Override
	public int compare(WCClaimPageRectangle o1, WCClaimPageRectangle o2) {
		Double d1 = Double.valueOf(o1.getRectangle().getX());
		Double d2 = Double.valueOf(o2.getRectangle().getX());
		return d1.compareTo(d2);
	}
}
