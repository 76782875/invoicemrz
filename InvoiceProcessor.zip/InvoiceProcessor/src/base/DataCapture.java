package base;

public class DataCapture {
	public static void main(String[] args){
		
	}
}
