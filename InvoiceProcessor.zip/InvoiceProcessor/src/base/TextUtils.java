package base;

import org.apache.commons.lang3.StringUtils;

public class TextUtils {
	
	public static void main(String args[]){
		System.out.println(isMoneyValue("abc"));
		System.out.println(isMoneyValue("23"));
		System.out.println(isMoneyValue("2.30"));
		System.out.println(isMoneyValue("$2.30"));
		System.out.println(isMoneyValue("$1,172.30"));
		System.out.println(isMoneyValue("$1,172.30"));
		System.out.println(isMoneyValue("127."));
		System.out.println(isMoneyValue("AUD3.50"));
		
		System.out.println(isWord("er2g3,"));
		System.out.println(isWord("er2g3"));
		System.out.println(isWord("erg,"));
		System.out.println(isWord("erg"));
		System.out.println(isAlphaNumericPunctuation("erg,"));
		System.out.println(isAlphaNumeric("erg"));
		System.out.println(isAlphaNumericPunctuation("er2g3,"));
		System.out.println(isAlphaNumeric("er2g3"));
		
		System.out.println(StringUtils.isAllUpperCase("ER2G3"));
		System.out.println(StringUtils.isAllUpperCase("ER2G3".trim().replaceAll("[^a-zA-Z ]", "")));
		System.out.println(StringUtils.isAllUpperCase("22.50".trim().replaceAll("[^a-zA-Z ]", "")));
		System.out.println(StringUtils.isAllUpperCase("ERG"));
		
		System.out.println(ContentCategory.NONE.ordinal());
		System.out.println(PresentationCategory.NONE.ordinal());
	}
	
	private static boolean isMoneyValue(String text){
		if (!text.contains(".") || text.contains(".") && text.endsWith(".")){
			return false;
		}
		
		if (StringUtils.isNumeric(text.trim().replace("AUD", "").replaceAll("[$.,]", ""))){
			return true;
		}
		return false;
	}
	
	private static boolean isWord(String text){
		return StringUtils.isAlpha(text.trim());
	}
	
	private static boolean isNumeric(String text){
		return StringUtils.isNumeric(text.trim());
	}
	
	private static boolean isAlphaNumeric(String text){
		return StringUtils.isAlphanumeric(text.trim());
	}
	
	private static boolean isAlphaNumericPunctuation(String text){
		return StringUtils.isAlphanumeric(text.trim().replaceAll("\\W", ""));
	}
	
	private static boolean isLine(String text){
		
		if (!text.contains("_")){
			return false;
		}
		
		String line = text.trim().replaceAll("_", "");
		if (line.trim().isEmpty()){
			return true;
		}
		return false;
	}
	
	private static boolean isMoneySign(String text){
		if (text.trim().equals("$")
				|| text.trim().equals("AUD")){
			return true;
		}
		return false;
	}
	
	private static boolean isWordEndsWithColon(String text){
		if (text.endsWith(":")
				&& StringUtils.isAlpha(text.substring(0, text.length() - 1))){
			return true;
		}
		return false;
	}
	
	public static ContentCategory classifyContent(String text){
		if (text.trim().isEmpty()){
			return ContentCategory.NONE;
		}else if (isLine(text)){
			return ContentCategory.LINE;
		}else if (isMoneyValue(text)){
			return ContentCategory.MONEY;
		}else if (isWord(text)){
			return ContentCategory.WORD;
		}else if (isNumeric(text)){
			return ContentCategory.NUMERIC;
		}else if (isAlphaNumeric(text)){
			return ContentCategory.ALPHANUMERIC;
		}else if (isWordEndsWithColon(text)){
			return ContentCategory.WORDWITHCOLON;
		}else if (isAlphaNumericPunctuation(text)){
			return ContentCategory.ALPHANUMERICPUNCTUATION;
		}else if (isMoneySign(text)){
			return ContentCategory.MONEYSIGN;
		}
		
		return ContentCategory.RUBBISH;
	}
	
	public static PresentationCategory getPresentation(String text){
		if (text.trim().isEmpty()){
			return PresentationCategory.NONE;
		}else if (StringUtils.isAllUpperCase(text.trim().replaceAll("[^a-zA-Z ]", ""))){
			return PresentationCategory.ALLUPPERWORD;
		}else if (StringUtils.isAllLowerCase(text.trim())){
			return PresentationCategory.ALLLOWERWORD;
		}
		
		return  PresentationCategory.WORD;
	}
}
