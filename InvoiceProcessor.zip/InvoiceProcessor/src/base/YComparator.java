package base;

import java.util.Comparator;

public class YComparator implements Comparator<WCClaimPageRectangle>{

	@Override
	public int compare(WCClaimPageRectangle o1, WCClaimPageRectangle o2) {
		Double d1 = Double.valueOf(o1.getRectangle().getY());
		Double d2 = Double.valueOf(o2.getRectangle().getY());
		return d1.compareTo(d2);
	}

}
