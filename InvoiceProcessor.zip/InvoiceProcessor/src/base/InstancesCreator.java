package base;

import static org.bytedeco.javacpp.lept.pixDestroy;

import static org.bytedeco.javacpp.lept.pixReadTiff;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.bytedeco.javacpp.BytePointer;
import org.bytedeco.javacpp.lept.PIX;

import com.mortennobel.imagescaling.ResampleFilters;
import com.mortennobel.imagescaling.ResampleOp;

import trees.ARunnerForT;
import trees.AToTreeInstanceConverter;

public class InstancesCreator {
	
	public static void main(String[] args) throws Exception {
		ZipFile zipFile = new ZipFile("C:\\Users\\u392576\\Downloads\\send\\pdfs\\hertz-native.zip");
	    Enumeration<? extends ZipEntry> entries = zipFile.entries();

	    File file = new File ("results.txt");
	    PrintWriter printWriter = new PrintWriter(file);
	    
	    while(entries.hasMoreElements()){
	        ZipEntry entry = entries.nextElement();
	        String fileName = entry.getName();
	        //printWriter.write(fileName + "\n");
	        
	        InputStream stream = zipFile.getInputStream(entry);
	        List<Object[]> instances = process(stream);
	        stream.close();
	        //String instanceStr = String.join("\t", (String[])instance);
	        for (Object[] inst : instances){
		        
	        	Class[] signature = new Class[1];
		        signature[0] = Object[].class;
		        
		        Object[] toTreeInstance = AToTreeInstanceConverter.convert(InstancesCreator.total, InstancesCreator.N, inst);
		        Object[] cArgs = new Object[1];
		        cArgs[0] = toTreeInstance;
		        
				Object total = trees.ARunnerForT.callStaticMethod("Hertz", "classify", signature, cArgs);
				if (total != null){
					if ((Double)total == 1.0){
						String instanceStr = "";
				        for (Object i : inst){
				        	if (!instanceStr.isEmpty()){
				        		instanceStr += "\t";
				        	}
				        	instanceStr += String.valueOf(i);
				        }
				        System.out.println(fileName + "\t" + String.valueOf(inst[42]));
				        printWriter.write(fileName + "\t" + instanceStr + "\n");
					}
				}
	        }
	        
	    }

	    printWriter.close();
	}
	
	public static void main2(String[] args) throws Exception {
		ZipFile zipFile = new ZipFile("C:\\Users\\u392576\\Downloads\\send\\pdfs\\hertz-native.zip");
	    Enumeration<? extends ZipEntry> entries = zipFile.entries();

	    File file = new File ("instances.txt");
	    PrintWriter printWriter = new PrintWriter(file);
	    
	    while(entries.hasMoreElements()){
	        ZipEntry entry = entries.nextElement();
	        String fileName = entry.getName();
	        //printWriter.write(fileName + "\n");
	        
	        InputStream stream = zipFile.getInputStream(entry);
	        List<Object[]> instances = process(stream);
	        stream.close();
	        //String instanceStr = String.join("\t", (String[])instance);
	        for (Object[] inst : instances){
		        String instanceStr = "";
		        for (Object i : inst){
		        	if (!instanceStr.isEmpty()){
		        		instanceStr += "\t";
		        	}
		        	instanceStr += String.valueOf(i);
		        }
		        System.out.println(fileName + "\t" + instanceStr);
		        printWriter.write(fileName + "\t" + instanceStr + "\n");
	        }
	        
	    }

	    printWriter.close();
	}
	
	static int N = 9;
	static int total = 3 + 3 + 4*N + 3*N + (N -1);
	static String TEMP = "//tmp";
	static TessAPIWrapper api;
	
	public void close() {
		api.close();
	}

	public static List<Object[]> process(InputStream in) {	
		List<Object[]> results = new LinkedList<Object[]>();
		Object[] result = new Object[total];
		result[0] = false;
		result[1] = "notretrieved";
		result[2] = false;

		result[3] = 0;
		result[4] = 0.0;
		result[5] = 0.0;
    	
    	if (in == null){
    		return results;
    	}
    	
    	try {
			PDDocument document = PDDocument.load(in);
			List<PDPage> allPages = document.getDocumentCatalog().getAllPages();

			result[3] = allPages.size();
			
			if (allPages.size() == 0){
				result[0] = true;
				result[1] = "empty";
				return results;
			}
			
			String text = "";
			int numImages = 0;
			
			PDFTextStripper pdfStripper = new PDFTextStripper();
			pdfStripper.setEndPage(1);
			text = pdfStripper.getText(document).trim();
			
			for (int i = 0; i < allPages.size() && i == 0; i++) {
				PDPage page = (PDPage) allPages.get(i);
		        PDResources resources = page.getResources();
		        
		        if (resources != null){
			        Map pageImages = resources.getImages();
			        
			        if (pageImages != null) {
			        	numImages += pageImages.size();
			        }
		        }
		        i++;
			}
			
			String tessOutput = "";
			if (text.isEmpty() && numImages == 0){
				result[0] = true;
				result[1] = "empty";
				return results;
			}else if (text.isEmpty() && numImages == 1
					||
					text.isEmpty() && numImages > 1
					|| 
					((text.length() < 240) && numImages > 0)
					){
				BufferedImage resizedImage = null;
				
				if (text.isEmpty() && numImages == 1){
					result[0] = true;
					result[1] = "scan";
					
					PDPage page = (PDPage) allPages.get(0);
			        PDResources resources = page.getResources();
			        Map pageImages = resources.getImages();
			        String key = (String) pageImages.keySet().iterator().next();
		            PDXObjectImage image = (PDXObjectImage) pageImages.get(key);
		            resizedImage = image.getRGBImage();
	            }else{
	            	result[0] = true;
					result[1] = "unclear";
					try{
						resizedImage = allPages.get(0).convertToImage(BufferedImage.TYPE_INT_RGB, 72); 
					}catch (Exception ex){
						return results;
					}
	            }
		        
	            int rw = resizedImage.getWidth()*1;//6592;
				ResampleOp resampleOp = new ResampleOp(rw,(rw * resizedImage.getHeight()) / resizedImage.getWidth() );
				resampleOp.setFilter(ResampleFilters.getBSplineFilter()); 
				resizedImage = resampleOp.filter(resizedImage, null);
				
				String tempImageFileName = TEMP + File.separator;
				File tmpFile = new File(tempImageFileName);
				try {
					ImageIO.write(resizedImage, "tif", tmpFile);
				} catch (Exception e) {
					result[1] = "notwritten";
					return results;
				}
				
				PIX pixImage = pixReadTiff(tempImageFileName, 0);
				try {
					FileUtils.forceDelete(new File(tempImageFileName));
				} catch (Exception e) {
					System.out.println("Can not delete " + tempImageFileName);
				}
				
				if (pixImage == null){
					result[1] = "pix";
					return results;
	    		}
				
				if (api.getAPI() == null){
					result[1] = "api";
					return results;
				}
				
				api.getAPI().SetImage(pixImage);
				
				BytePointer outText = api.getAPI().GetHOCRText(0);
				tessOutput = outText.getString();
		        
				result[4] = Double.valueOf(pixImage.w());
				result[5] = Double.valueOf(pixImage.h());
				
				pixDestroy(pixImage);
				if (outText != null){
				    outText.deallocate();
				}
			}else {
				result[1] = "text";
				result[4] = Double.valueOf(allPages.get(0).getMediaBox().getWidth());
				result[5] = Double.valueOf(allPages.get(0).getMediaBox().getHeight());
			}
			
			PDFTextCoordinates coords = new PDFTextCoordinates();
	    	try {
	    		PDFPageContent content = null;
	    		if (result[1].equals("scan")){
	    			content = coords.getTIFFContents(tessOutput);
				}else{
					content = coords.getContents(document);
				}
	    		// start of per element instance builder
				for (WCClaimPageRectangle rect : content.getAll()){
					
					int index = 6;
					for (int o = 0; o < N; o++){
						result[index] = 0.0;
						index++;
						result[index] = 0.0;
						index++;
						result[index] = 0.0;
						index++;
						result[index] = 0.0;
						index++;
				    }
					// values
				    for (int o = 0; o < N; o++){
				    	result[index] = "";
						index++;
				    }
				    // category, presentation
				    for (int o = 0; o < N; o++){
				    	result[index] = ContentCategory.NONE;
						index++;
				    }
				    for (int o = 0; o < N; o++){
				    	result[index] = PresentationCategory.NONE;
						index++;
				    }
				    // distance
				    for (int o = 0; o < N-1; o++){
				    	result[index] = 0.0;
						index++;
				    }
					
					WCClaimPageRectangle left = content.getLeft(rect);
					WCClaimPageRectangle top = content.getTop(rect);
					WCClaimPageRectangle right = content.getRight(rect);
					WCClaimPageRectangle bottom = content.getBottom(rect);
					
					WCClaimPageRectangle topleft = content.getLeftTop(rect);
					WCClaimPageRectangle topright = content.getRightTop(rect);
					WCClaimPageRectangle bottomright = content.getRightBottom(rect);
					WCClaimPageRectangle bottomleft = content.getLeftBottom(rect);
					
					double distanceFromLeft = 0;
					double distanceFromTop = 0;
					double distanceFromRight = 0;
					double distanceFromBottom = 0;
					
					double distanceFromTopLeft = 0;
					double distanceFromTopRight = 0;
					double distanceFromBottomRight = 0;
					double distanceFromBottomLeft = 0;
					
					result[3+3] = rect.getRectangle().getX();
					result[4+3] = rect.getRectangle().getY();
					result[5+3] = rect.getRectangle().getWidth();
					result[6+3] = rect.getRectangle().getHeight();
					
					if (left != null){
						distanceFromLeft = rect.getRectangle().getX() - left.getRectangle().getWidth();
						result[7+3] = left.getRectangle().getX();
						result[8+3] = left.getRectangle().getY();
						result[9+3] = left.getRectangle().getWidth();
						result[10+3] = left.getRectangle().getHeight();
						
						result[40+3] = left.getText();
						result[49+3] = TextUtils.classifyContent(left.getText());
						result[58+3] = TextUtils.getPresentation(left.getText());
						result[66+3] = distanceFromLeft;
					}
					
					if (top != null){
						distanceFromTop = rect.getRectangle().getY() - top.getRectangle().getHeight();
						result[11+3] = top.getRectangle().getX();
						result[12+3] = top.getRectangle().getY();
						result[13+3] = top.getRectangle().getWidth();
						result[14+3] = top.getRectangle().getHeight();
						
						result[41+3] = top.getText();
						result[50+3] = TextUtils.classifyContent(top.getText());
						result[59+3] = TextUtils.getPresentation(top.getText());
						result[67+3] = distanceFromTop;
					}
					
					if (right != null){
						distanceFromRight = Math.abs(rect.getRectangle().getWidth() - right.getRectangle().getX());
						result[15+3] = right.getRectangle().getX();
						result[16+3] = right.getRectangle().getY();
						result[17+3] = right.getRectangle().getWidth();
						result[18+3] = right.getRectangle().getHeight();
						
						result[42+3] = right.getText();
						result[51+3] = TextUtils.classifyContent(right.getText());
						result[60+3] = TextUtils.getPresentation(right.getText());
						result[68+3] = distanceFromRight;
					}
					
					if (bottom != null){
						distanceFromBottom = Math.abs(rect.getRectangle().getHeight() - bottom.getRectangle().getY());
						result[19+3] = bottom.getRectangle().getX();
						result[20+3] = bottom.getRectangle().getY();
						result[21+3] = bottom.getRectangle().getWidth();
						result[22+3] = bottom.getRectangle().getHeight();
						
						result[43+3] = bottom.getText();
						result[52+3] = TextUtils.classifyContent(bottom.getText());
						result[61+3] = TextUtils.getPresentation(bottom.getText());
						result[69+3] = distanceFromBottom;
					}
					
					if (topleft != null){
						distanceFromTopLeft = Math.sqrt(Math.pow(rect.getRectangle().getX() - topleft.getRectangle().getWidth(), 2) + Math.pow(rect.getRectangle().getY() - topleft.getRectangle().getHeight(), 2));
						result[23+3] = topleft.getRectangle().getX();
						result[24+3] = topleft.getRectangle().getY();
						result[25+3] = topleft.getRectangle().getWidth();
						result[26+3] = topleft.getRectangle().getHeight();
						
						result[44+3] = topleft.getText();
						result[53+3] = TextUtils.classifyContent(topleft.getText());
						result[62+3] = TextUtils.getPresentation(topleft.getText());
						result[70+3] = distanceFromTopLeft;
					}
					
					if (topright != null){
						distanceFromTopRight = Math.sqrt(Math.pow(rect.getRectangle().getWidth() - topright.getRectangle().getX(), 2) + Math.pow(rect.getRectangle().getY() - topright.getRectangle().getHeight(), 2));
						result[27+3] = topright.getRectangle().getX();
						result[28+3] = topright.getRectangle().getY();
						result[29+3] = topright.getRectangle().getWidth();
						result[30+3] = topright.getRectangle().getHeight();
						
						result[45+3] = topright.getText();
						result[54+3] = TextUtils.classifyContent(topright.getText());
						result[63+3] = TextUtils.getPresentation(topright.getText());
						result[71+3] = distanceFromTopRight;
					}
					
					if (bottomright != null){
						distanceFromBottomRight = Math.sqrt(Math.pow(rect.getRectangle().getWidth() - bottomright.getRectangle().getX(), 2) + Math.pow(rect.getRectangle().getHeight() - bottomright.getRectangle().getY(), 2));
						result[31+3] = bottomright.getRectangle().getX();
						result[32+3] = bottomright.getRectangle().getY();
						result[33+3] = bottomright.getRectangle().getWidth();
						result[34+3] = bottomright.getRectangle().getHeight();
						
						result[46+3] = bottomright.getText();
						result[55+3] = TextUtils.classifyContent(bottomright.getText());
						result[64+3] = TextUtils.getPresentation(bottomright.getText());
						result[72+3] = distanceFromBottomRight;
					}
					
					if (bottomleft != null){
						distanceFromBottomLeft = Math.sqrt(Math.pow(rect.getRectangle().getX() - bottomleft.getRectangle().getWidth(), 2) + Math.pow(rect.getRectangle().getY() - bottomleft.getRectangle().getY(), 2));
						result[35+3] = bottomleft.getRectangle().getX();
						result[36+3] = bottomleft.getRectangle().getY();
						result[37+3] = bottomleft.getRectangle().getWidth();
						result[38+3] = bottomleft.getRectangle().getHeight();
						
						result[47+3] = bottomleft.getText();
						result[56+3] = TextUtils.classifyContent(bottomleft.getText());
						result[65+3] = TextUtils.getPresentation(bottomleft.getText());
						result[73+3] = distanceFromBottomLeft;
					}
					
					result[39+3] = rect.getText();
					result[48+3] = TextUtils.classifyContent(rect.getText());
					result[57+3] = TextUtils.getPresentation(rect.getText());
					
					result[0] = true;
					result[2] = true;
					
					Object[] r = result.clone();
					results.add(r);
				}
				// end of per element instance builder
				
				document.close();
			} catch (Exception e) {
				result[0] = true;
			}
			
		} catch (Exception e) {
			result[0] = true;
			result[1] = "unknown";
		}
    	
    	return results;
	}
}
